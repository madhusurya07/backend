import React from 'react'

function Home() {
    return (
        <div>
            <h1>home</h1>
        </div>
    )
}
<h1>home</h1>
export default Home
